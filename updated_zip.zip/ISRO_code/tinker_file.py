import tkinter as tk
from tkinter import filedialog
import requests
import webbrowser
import random

# Function to select file 1
def select_file_1():
    file_path = filedialog.askopenfilename()
    if file_path:
        file_name = file_path.split("/")[-1]  # Extract the filename
        files['file1'] = (file_name, open(file_path, 'rb'))
        check_buttons()

# Function to select file 2
def select_file_2():
    file_path = filedialog.askopenfilename()
    if file_path:
        file_name = file_path.split("/")[-1]  # Extract the filename
        files['file2'] = (file_name, open(file_path, 'rb'))
        check_buttons()

# Function to check the buttons status
def check_buttons():
    button1_checkbox.config(text="File 1 Added" if 'file1' in files else "Select File 1", fg="#333")
    button2_checkbox.config(text="File 2 Added" if 'file2' in files else "Select File 2", fg="#333")
    button3.config(state=tk.NORMAL if 'file1' in files and 'file2' in files else tk.DISABLED)

# Function to create new window
def create_new_window():
    if 'file1' in files and 'file2' in files:
        try:
            response = requests.post('http://127.0.0.1:5000/result', files=files)

            if response.status_code == 200:
                print(response.text)
                webbrowser.open('http://127.0.0.1:5000/result')
            else:
                print("Error:", response.text)
        except Exception as e:
            print("Error:", str(e))

# Function to move the circles
def move_circles():
    global circles
    for circle in circles:
        dx, dy = circle[2], circle[3]
        if circle[0] + dx > canvas.winfo_width() or circle[0] + dx < 0:
            dx = -dx
        if circle[1] + dy > canvas.winfo_height() or circle[1] + dy < 0:
            dy = -dy
        circle[0] += dx
        circle[1] += dy
        canvas.move(circle[4], dx, dy)
    root.after(50, move_circles)  # Move the circles every 50 milliseconds

# Tkinter GUI
root = tk.Tk()
root.title("File Selector")
root.geometry("800x600")

files = {}

# Background Animation
canvas = tk.Canvas(root, bg="white")
canvas.pack(fill=tk.BOTH, expand=True)

circles = []

# Create 20 random circles with random positions, radii, and velocities
for _ in range(20):
    x = random.randint(0, 800)
    y = random.randint(0, 600)
    r = random.randint(10, 30)
    dx = random.randint(-5, 5)
    dy = random.randint(-5, 5)
    circle = canvas.create_oval(x - r, y - r, x + r, y + r, fill="blue")
    circles.append([x, y, dx, dy, circle])

move_circles()

# Functionality Frame
functionality_frame = tk.Frame(root, bg="#f0f0f0", padx=20, pady=20)
functionality_frame.pack(pady=20)

button1 = tk.Button(functionality_frame, text="Select File 1", command=select_file_1, font=("Arial", 12), bg="#4CAF50", fg="#fff", padx=10)
button1.grid(row=0, column=0, padx=10, pady=10)

button1_checkbox = tk.Label(functionality_frame, text="Select File 1", bg="#f0f0f0", fg="#333", font=("Arial", 10))
button1_checkbox.grid(row=1, column=0, padx=10, pady=5)

button2 = tk.Button(functionality_frame, text="Select File 2", command=select_file_2, font=("Arial", 12), bg="#2196F3", fg="#fff", padx=10)
button2.grid(row=0, column=1, padx=10, pady=10)

button2_checkbox = tk.Label(functionality_frame, text="Select File 2", bg="#f0f0f0", fg="#333", font=("Arial", 10))
button2_checkbox.grid(row=1, column=1, padx=10, pady=5)

button3 = tk.Button(root, text="Go to New Page", command=create_new_window, font=("Arial", 12), state=tk.DISABLED, bg="#333", fg="#fff", padx=10)
button3.pack(pady=20)

root.mainloop()
