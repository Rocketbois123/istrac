const cafelist=document.querySelector('#cafe-list');
const form=document.querySelector('#add-cafe-form');

function caferender(doc){
    let li=document.createElement('li');
    let name=document.createElement('span');
    let city=document.createElement('span');
    let cross=document.createElement('div');

    li.setAttribute('data-id',doc.id);
    name.textContent=doc.data().Name;
    city.textContent=doc.data().City;
    cross.textContent='x';

    li.appendChild(name);
    li.appendChild(city);
    li.appendChild(cross);
    cafelist.appendChild(li);

    cross.addEventListener('click',(e)=>{
        e.stopPropagation();
        let id=e.target.parentElement.getAttribute('data-id');
        db.collection('cafes').doc(id).delete();
    })
}

db.collection('cafes').get().then((snapshot)=>{
    snapshot.docs.forEach(doc => {
        caferender(doc);
    });
})

form.addEventListener('submit',(e)=>{
    e.preventDefault();
    db.collection('cafes').add({
        Name:form.Name.value,
        City:form.City.value
    })
    form.Name.value='';
    form.City.value='';
})