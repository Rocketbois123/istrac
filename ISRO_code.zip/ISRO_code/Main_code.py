from flask import Flask, render_template, request
import subprocess

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route("/", methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        subprocess.Popen(["python", "tinker_file.py"])
    return render_template("index.html")


@app.route("/result", methods=['GET','POST'])
def result():
    try:
        file1_location = f"{app.config['UPLOAD_FOLDER']}/file1.txt"
        file2_location = f"{app.config['UPLOAD_FOLDER']}/file2.txt"

        result = f"File 1 Location: {file1_location}\nFile 2 Location: {file2_location}"
        return render_template("result.html", result=result)
    except Exception as e:
        return str(e)

if __name__ == "__main__":
    app.run(debug=True, threaded=True)
