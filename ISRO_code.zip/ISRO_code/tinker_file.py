import tkinter as tk
from tkinter import filedialog
import requests
import webbrowser

def select_file_1():
    file_path = filedialog.askopenfilename()
    if file_path:
        file_name = file_path.split("/")[-1]  # Extract the filename
        files['file1'] = (file_name, open(file_path, 'rb'))
        check_buttons()

def select_file_2():
    file_path = filedialog.askopenfilename()
    if file_path:
        file_name = file_path.split("/")[-1]  # Extract the filename
        files['file2'] = (file_name, open(file_path, 'rb'))
        check_buttons()

def check_buttons():
    if 'file1' in files:
        button1_checkbox.select()
    else:
        button1_checkbox.deselect()

    if 'file2' in files:
        button2_checkbox.select()
    else:
        button2_checkbox.deselect()

    if 'file1' in files and 'file2' in files:
        button3.config(state=tk.NORMAL)
    else:
        button3.config(state=tk.DISABLED)

def create_new_window():
    if 'file1' in files and 'file2' in files:
        try:
            response = requests.post('http://127.0.0.1:5000/result', files=files)

            if response.status_code == 200:
                print(response.text)
                webbrowser.open('http://127.0.0.1:5000/result')
            else:
                print("Error:", response.text)
        except Exception as e:
            print("Error:", str(e))

# Tkinter GUI
root = tk.Tk()
root.title("File Selector")
root.geometry("800x600")

files = {}

button1 = tk.Button(root, text="Select File 1", command=select_file_1, font=("Arial", 12))
button1.place(relx=0.3, rely=0.2, anchor=tk.CENTER)

button1_checkbox = tk.Checkbutton(root, text="File 1 Added", state=tk.DISABLED)
button1_checkbox.place(relx=0.3, rely=0.3, anchor=tk.CENTER)

button2 = tk.Button(root, text="Select File 2", command=select_file_2, font=("Arial", 12))
button2.place(relx=0.7, rely=0.2, anchor=tk.CENTER)

button2_checkbox = tk.Checkbutton(root, text="File 2 Added", state=tk.DISABLED)
button2_checkbox.place(relx=0.7, rely=0.3, anchor=tk.CENTER)

button3 = tk.Button(root, text="Go to New Page", command=create_new_window, font=("Arial", 12), state=tk.DISABLED)
button3.place(relx=0.5, rely=0.8, anchor=tk.CENTER)

root.mainloop()
